import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import castle from "@/assets/castle.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Villain Academy — The School of Ultimate Villainy" },
      { name: "description", content: "Where heroes fear to enter. Train your villain, conquer challenges, unlock the final rank." },
      { property: "og:title", content: "Villain Academy — The School of Ultimate Villainy" },
      { property: "og:description", content: "Where heroes fear to enter. Train your villain at Villain Academy." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Skill = "Dark Magic" | "Cunning" | "Intimidation" | "Combat";
const SKILLS: Skill[] = ["Dark Magic", "Cunning", "Intimidation", "Combat"];

const VILLAINS = [
  { id: "morgra", name: "Morgra the Hexbinder", title: "Sorceress of the Crimson Veil", icon: "🜏", bio: "Weaver of curses and ancient blood rites.", base: { "Dark Magic": 30, Cunning: 15, Intimidation: 10, Combat: 5 } },
  { id: "vex", name: "Lord Vex", title: "Master of Shadows & Schemes", icon: "♛", bio: "Every kingdom falls to whispers before swords.", base: { "Dark Magic": 10, Cunning: 30, Intimidation: 15, Combat: 5 } },
  { id: "grimhold", name: "Grimhold the Dread", title: "Warlord of the Iron Abyss", icon: "⚔", bio: "His armor is forged from the shields of fallen heroes.", base: { "Dark Magic": 5, Cunning: 5, Intimidation: 25, Combat: 30 } },
] as const;

const CHALLENGES = [
  { id: "c1", name: "Curse the Village Well", skill: "Dark Magic" as Skill, xp: 50 },
  { id: "c2", name: "Betray the Royal Council", skill: "Cunning" as Skill, xp: 60 },
  { id: "c3", name: "Terrify the Knight's Order", skill: "Intimidation" as Skill, xp: 55 },
  { id: "c4", name: "Duel the Champion of Light", skill: "Combat" as Skill, xp: 70 },
  { id: "c5", name: "Summon the Shadow Legion", skill: "Dark Magic" as Skill, xp: 90 },
  { id: "c6", name: "Steal the Sunstone Crown", skill: "Cunning" as Skill, xp: 80 },
];

const RANKS = [
  { xp: 0, name: "Initiate of Shadows" },
  { xp: 100, name: "Apprentice of Dread" },
  { xp: 250, name: "Dark Adept" },
  { xp: 400, name: "Overlord" },
  { xp: 600, name: "Supreme Villain of the Academy" },
];

type State = { villain: string | null; xp: number; points: number; skills: Record<Skill, number>; done: string[] };
const KEY = "villain-academy-progress";
const empty: State = { villain: null, xp: 0, points: 0, skills: { "Dark Magic": 0, Cunning: 0, Intimidation: 0, Combat: 0 }, done: [] };

function Index() {
  const [s, setS] = useState<State>(empty);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    try { const raw = localStorage.getItem(KEY); if (raw) setS(JSON.parse(raw)); } catch {}
    const t = setTimeout(() => setLoading(false), 1400);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => { if (!loading) localStorage.setItem(KEY, JSON.stringify(s)); }, [s, loading]);

  const flash = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2500); };
  const v = VILLAINS.find((x) => x.id === s.villain);
  const rankIdx = RANKS.reduce((a, r, i) => (s.xp >= r.xp ? i : a), 0);
  const rank = RANKS[rankIdx]!;
  const next = RANKS[rankIdx + 1];
  const finalUnlocked = rankIdx === RANKS.length - 1;

  const choose = (id: string) => { const vil = VILLAINS.find((x) => x.id === id)!; setS({ ...empty, villain: id, skills: { ...vil.base } }); flash(`${vil.name} has enrolled in Villain Academy.`); };
  const complete = (c: (typeof CHALLENGES)[number]) => {
    if (s.done.includes(c.id)) return;
    const newXp = s.xp + c.xp;
    const newRank = RANKS.reduce((a, r, i) => (newXp >= r.xp ? i : a), 0);
    setS({ ...s, xp: newXp, points: s.points + 2, done: [...s.done, c.id], skills: { ...s.skills, [c.skill]: Math.min(100, s.skills[c.skill] + 5) } });
    flash(newRank > rankIdx ? `RANK UNLOCKED: ${RANKS[newRank]!.name}` : `+${c.xp} XP · +2 Skill Points`);
  };
  const upgrade = (k: Skill) => { if (s.points < 1 || s.skills[k] >= 100) return; setS({ ...s, points: s.points - 1, skills: { ...s.skills, [k]: Math.min(100, s.skills[k] + 10) } }); };
  const reset = () => { if (confirm("Abandon your villain and erase all progress?")) setS(empty); };

  if (loading)
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-background">
        <h1 className="animate-flicker font-display text-4xl text-primary text-blood md:text-6xl">VILLAIN ACADEMY</h1>
        <p className="mt-4 tracking-[0.4em] text-muted-foreground">SUMMONING THE DARKNESS…</p>
      </div>
    );

  return (
    <div className="relative min-h-screen bg-cover bg-fixed bg-center" style={{ backgroundImage: `url(${castle})` }}>
      <div className="veil absolute inset-0" />
      <div className="relative">
        <nav className="flex items-center justify-between border-b px-6 py-4 backdrop-blur-sm">
          <span className="font-display text-lg text-primary text-blood">☠ VILLAIN ACADEMY</span>
          {v && <button onClick={reset} className="text-sm text-muted-foreground hover:text-primary">Abandon Villain</button>}
        </nav>

        <header className="px-6 py-20 text-center">
          <p className="tracking-[0.5em] text-gold">WHERE HEROES FEAR TO ENTER.</p>
          <h1 className="mt-4 animate-flicker font-display text-5xl text-primary text-blood md:text-8xl">VILLAIN ACADEMY</h1>
          <p className="mt-3 font-display text-xl md:text-2xl">The School of Ultimate Villainy</p>
          <p className="mx-auto mt-6 max-w-xl text-lg italic text-muted-foreground">"Welcome to Villain Academy, where darkness becomes power."</p>
        </header>

        <main className="mx-auto max-w-6xl px-6 pb-20">
          {!v ? (
            <section>
              <h2 className="mb-8 text-center font-display text-3xl text-gold">Choose Your Villain</h2>
              <div className="grid gap-6 md:grid-cols-3">
                {VILLAINS.map((x) => (
                  <div key={x.id} className="rounded-lg border bg-card p-6 backdrop-blur transition hover:-translate-y-1 hover:shadow-glow">
                    <div className="text-6xl text-primary text-blood">{x.icon}</div>
                    <h3 className="mt-4 font-display text-xl">{x.name}</h3>
                    <p className="text-gold">{x.title}</p>
                    <p className="mt-2 text-muted-foreground">{x.bio}</p>
                    <div className="mt-4 space-y-2">{SKILLS.map((k) => <Bar key={k} label={k} value={x.base[k]} />)}</div>
                    <button onClick={() => choose(x.id)} className="mt-6 w-full rounded border border-primary bg-primary py-2 font-display text-primary-foreground hover:shadow-glow">Enroll</button>
                  </div>
                ))}
              </div>
            </section>
          ) : (
            <section className="grid gap-6 lg:grid-cols-3">
              <div className="rounded-lg border bg-card p-6 backdrop-blur">
                <p className="text-sm tracking-widest text-muted-foreground">VILLAIN ACADEMY · TRAINING DASHBOARD</p>
                <div className="mt-3 text-5xl text-primary text-blood">{v.icon}</div>
                <h2 className="mt-2 font-display text-2xl">{v.name}</h2>
                <p className="text-gold">{rank.name}</p>
                <div className="mt-4"><Bar label={`XP ${s.xp}${next ? ` / ${next.xp}` : ""}`} value={next ? ((s.xp - rank.xp) / (next.xp - rank.xp)) * 100 : 100} /></div>
                <p className="mt-4">Skill Points: <span className="font-bold text-primary">{s.points}</span></p>
                <div className="mt-4 space-y-3">
                  {SKILLS.map((k) => (
                    <div key={k} className="flex items-end gap-2">
                      <div className="flex-1"><Bar label={k} value={s.skills[k]} /></div>
                      <button disabled={s.points < 1 || s.skills[k] >= 100} onClick={() => upgrade(k)} className="rounded border px-2 text-primary disabled:opacity-30">+</button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-lg border bg-card p-6 backdrop-blur lg:col-span-2">
                <h2 className="font-display text-2xl text-gold">Villain Academy Challenges</h2>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  {CHALLENGES.map((c) => {
                    const d = s.done.includes(c.id);
                    return (
                      <button key={c.id} disabled={d} onClick={() => complete(c)} className="rounded border bg-secondary p-4 text-left transition hover:shadow-glow disabled:opacity-50">
                        <p className="font-display">{c.name}</p>
                        <p className="text-sm text-muted-foreground">{c.skill} · +{c.xp} XP</p>
                        <p className="mt-1 text-sm text-primary">{d ? "✓ Conquered" : "Undertake →"}</p>
                      </button>
                    );
                  })}
                </div>
                <h3 className="mt-8 font-display text-xl text-gold">Ranks & Achievements</h3>
                <ul className="mt-3 space-y-1">
                  {RANKS.map((r, i) => (
                    <li key={r.name} className={i <= rankIdx ? "text-foreground" : "text-muted-foreground opacity-50"}>
                      {i <= rankIdx ? "🜂" : "🔒"} {r.name} <span className="text-sm">({r.xp} XP)</span>
                    </li>
                  ))}
                </ul>
                {finalUnlocked && (
                  <div className="mt-6 rounded border border-primary p-6 text-center shadow-glow">
                    <p className="font-display text-3xl text-primary text-blood">SUPREME VILLAIN</p>
                    <p className="mt-2">You have mastered Villain Academy. The world kneels.</p>
                  </div>
                )}
              </div>
            </section>
          )}
        </main>

        <footer className="border-t px-6 py-8 text-center text-muted-foreground backdrop-blur-sm">
          <p className="font-display text-gold">THE WORLD FEARS WHAT IT CANNOT CONTROL.</p>
          <p className="mt-2 text-sm">© Villain Academy — The School of Ultimate Villainy</p>
        </footer>
      </div>
      {toast && <div className="fixed bottom-6 left-1/2 -translate-x-1/2 rounded border border-primary bg-popover px-6 py-3 font-display shadow-glow">{toast}</div>}
    </div>
  );
}

function Bar({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="flex justify-between text-sm"><span>{label}</span><span>{Math.round(value)}%</span></div>
      <div className="h-2 overflow-hidden rounded bg-muted"><div className="h-full bg-primary shadow-glow transition-all" style={{ width: `${Math.min(100, value)}%` }} /></div>
    </div>
  );
}
